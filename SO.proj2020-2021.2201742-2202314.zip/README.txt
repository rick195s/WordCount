Pedro Afonso Monteiro Pedro, 2201742
Ricardo dos Santos Franco, 2202314